
import openai
import requests
import pywhatkit
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
import streamlit as st
import webbrowser

# Set OpenAI API Key
openai.api_key = "OPenAi Key"

# Function to scrape content from a given URL
def scrape_article(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            title = soup.title.string if soup.title else "No Title Found"
            paragraphs = soup.find_all('p')
            content = " ".join([para.get_text() for para in paragraphs])
            return title, content
        else:
            return None, None
    except Exception as e:
        print(f"Error scraping {url}: {e}")
        return None, None



def summarize_article(title, content, url):

    system_prompt = """
    YOU ARE A HIGHLY SKILLED NEWS SUMMARIZER, SPECIALIZING IN CONDENSING COMPLEX ARTICLES INTO SIMPLE, EASY-TO-UNDERSTAND BULLET POINTS.
    ALWAYS INCLUDE THE SOURCE URL AT THE END OF THE SUMMARY.
    """
    
    prompt = f"""
    Summarize the following article titled '{title}' in simple bullet points (5-6 points maximum).
    
    Article Content: {content}
    
    After the bullet points, add a line indicating the full article can be read at: {url}
    """
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": prompt}
    ]
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages,
            max_tokens=1024
        )
        
        # Get the summary and append the URL
        summary = response['choices'][0]['message']['content']
        summary_with_url = f"{summary}\n\n*[Read the full article here]({url})*"
        
        return summary_with_url
    
    except openai.error.OpenAIError as e:
        print(f"Error summarizing article '{title}': {e}")
        return None

# Main scraping function
def scrape_economic_times(topic):
    """Scrapes headlines and URLs for the given topic from Economic Times."""
    base_url = f"https://economictimes.indiatimes.com/topic/{topic}"
    response = requests.get(base_url)

    if response.status_code != 200:
        return None, f"Failed to fetch data from Economic Times (Status Code: {response.status_code})"

    soup = BeautifulSoup(response.content, 'html.parser')

    # Find all <h2> tags that contain article titles and the corresponding <a> tags with URLs
    article_data = {}
    for h2 in soup.find_all('h2'):
        link = h2.find('a')
        if link:
            title = link.get_text()
            relative_url = link.get('href')
            full_url = "https://economictimes.indiatimes.com" + relative_url  # Concatenate base URL with relative URL
            article_data[title] = full_url

    headlines = list(article_data.items())[:10]  # Limit to top 10

    return headlines, None

def format_whatsapp_message(summaries):
    """
    Format the summaries with a specific header, date, and properly formatted URLs
    
    Args:
        summaries (str): Original summaries from AI summarization
    
    Returns:
        str: Formatted message ready for WhatsApp
    """
    # Get current date in the specified format
    current_date = datetime.now().strftime("%d-%b-%Y")
    
    # Create header
    formatted_message = f"AI News Summaries  {current_date}(By Rohit Mane Ai Agent)\n\n"
    
    # Split the summaries into individual articles
    articles = summaries.strip().split("\n\n**")
    
    for article in articles:
        if article.strip():
            # Remove extra ** if present
            article = article.replace("**", "").strip()
            
            # Split article into title and content
            parts = article.split("\n")
            
            if parts:
                # First line is the title
                title = parts[0].strip()
                
                # Separate content and URL
                content_lines = []
                url = None
                for line in parts[1:]:
                    if line.startswith("[Read the full article here]("):
                        # Extract URL from markdown link
                        url = line.split("(")[1].split(")")[0]
                    else:
                        content_lines.append(line)
                
                # Add title
                formatted_message += f"{title}\n"
                
                # Add bullet points
                for line in content_lines:
                    if line.strip() and not line.startswith("*["):
                        formatted_message += f"- {line.strip()}\n"
                
                # Add URL at the bottom
                if url:
                    formatted_message += f"Read more: {url}\n"
                
                # Add blank line between articles
                formatted_message += "\n"
    
    return formatted_message

# Update the send_whatsapp_summary function to use the new formatter
def send_whatsapp_summary(content, phone_number):
    """
    Send WhatsApp message with improved error handling and formatting
    """
    try:
        # Format the message
        formatted_message = format_whatsapp_message(content)
        
        # Get current time and schedule message 1 minute from now
        now = datetime.now()
        send_time = now + timedelta(seconds=60)
        hour = send_time.hour
        minute = send_time.minute

        # Send message using pywhatkit
        pywhatkit.sendwhatmsg(phone_number, formatted_message, hour, minute)
        
        # Return success message with scheduled time
        return f"Message scheduled to send at {hour:02d}:{minute:02d}"
    except Exception as e:
        # More detailed error handling
        error_message = f"Failed to send WhatsApp message: {str(e)}"
        print(error_message)
        return None

# Streamlit UI
def main():
    st.title("Economic Times News Scraper and Summarizer")

    # Input field for topic
    topic = st.text_input("Enter a news topic (e.g., technology, economy, sports):", "")

    # Initialize session state variables
    if 'headlines' not in st.session_state:
        st.session_state.headlines = []
    if 'selected_headlines' not in st.session_state:
        st.session_state.selected_headlines = {}
    if 'summaries' not in st.session_state:
        st.session_state.summaries = ""
    if 'whatsapp_number' not in st.session_state:
        st.session_state.whatsapp_number = ""
    if 'whatsapp_status' not in st.session_state:
        st.session_state.whatsapp_status = None

    # Fetch News Button
    if st.button("Fetch News"):
        if topic.strip():
            with st.spinner("Fetching news..."):
                headlines, error = scrape_economic_times(topic)

            if error:
                st.error(error)
            else:
                st.session_state.headlines = headlines
                st.session_state.selected_headlines = {
                    title: False for title, _ in headlines
                }  # Initialize checkboxes with False
                st.success(f"Found {len(headlines)} articles for '{topic}':")
        else:
            st.warning("Please enter a valid topic to search.")

    # Display headlines with checkboxes
    if st.session_state.headlines:
        st.subheader("Select articles to summarize:")
        for title, url in st.session_state.headlines:
            st.session_state.selected_headlines[title] = st.checkbox(
                title, value=st.session_state.selected_headlines.get(title, False)
            )

        # Button to summarize selected articles
        if st.button("AI Summarize"):
            selected_headlines = [
                (title, url)
                for title, url in st.session_state.headlines
                if st.session_state.selected_headlines[title]
            ]

            if selected_headlines:
                summaries = ""
                for title, url in selected_headlines:
                    st.write(f"Summarizing {title}...")
                    # Scrape article content and summarize
                    article_title, article_content = scrape_article(url)
                    if article_title and article_content:
                        summary = summarize_article(article_title, article_content,url)
                        if summary:
                            summaries += f"**{article_title}**\n{summary}\n\n"
                        else:
                            summaries += f"**{article_title}**\nSummary failed.\n\n"
                    else:
                        summaries += f"**{title}**\nFailed to retrieve content.\n\n"

                # Save summaries in session state
                st.session_state.summaries = summaries

                # Show summaries and provide WhatsApp option
                if summaries:
                    st.subheader("AI Summarized News:")
                    st.write(summaries)

    # WhatsApp sending section
    if st.session_state.summaries:
        st.subheader("Send Summaries")
        
        # Phone number input with session state persistence
        st.session_state.whatsapp_number = st.text_input(
            "Enter phone number to send via WhatsApp (include country code, e.g., +91XXXXXXXXXX):",
            value=st.session_state.whatsapp_number
        )

        # Send WhatsApp message button with explicit state management
        if st.button("Send Summary via WhatsApp"):
            if st.session_state.whatsapp_number.strip():
                # Validate phone number format
                if not st.session_state.whatsapp_number.startswith('+'):
                    st.error("Phone number must include country code (e.g., +91)")
                else:
                    # Attempt to send message
                    result = send_whatsapp_summary(
                        st.session_state.summaries, 
                        st.session_state.whatsapp_number
                    )
                    
                    # Update session state with result
                    if result:
                        st.session_state.whatsapp_status = result
                        st.success(result)
                    else:
                        st.error("Failed to schedule WhatsApp message")
            else:
                st.error("Please enter a valid phone number")

        # Display previous status if available
        if st.session_state.whatsapp_status:
            st.info(st.session_state.whatsapp_status)

if __name__ == "__main__":
    main()