
#   *****************OPenAi News Scrapper And Summarizer With Whatsapp Automation********************

import openai
import requests
from bs4 import BeautifulSoup
import pywhatkit
from datetime import datetime, timedelta

# Set OpenAI API Key
openai.api_key = "sk-dnaresearch01-LhztcG3GjvTP1fYNnlecT3BlbkFJ5feppL7CtddUFgIySm9e"

# Function to scrape content from a given URL
def scrape_article(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            title = soup.title.string if soup.title else "No Title Found"
            paragraphs = soup.find_all('p')
            content = " ".join([para.get_text() for para in paragraphs])
            return title, content
        else:
            return None, None
    except Exception as e:
        print(f"Error scraping {url}: {e}")
        return None, None

# Function to summarize an article
def summarize_article(title, content):
    system_prompt = """
    YOU ARE A HIGHLY SKILLED NEWS SUMMARIZER, SPECIALIZING IN CONDENSING COMPLEX ARTICLES INTO SIMPLE, EASY-TO-UNDERSTAND BULLET POINTS.
    """
    prompt = f"""
    Summarize the following article titled '{title}' in simple bullet points (5-6 points maximum). 
    Article Content: {content}
    """
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": prompt}
    ]
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages,
            max_tokens=1024
        )
        summary = response['choices'][0]['message']['content']
        return summary
    except openai.error.OpenAIError as e:
        print(f"Error summarizing article '{title}': {e}")
        return None

# Main function to process multiple URLs and send summaries via WhatsApp
def analyze_and_send(urls, phone_number):
    now = datetime.now()
    formatted_date = now.strftime("%d-%b-%Y")
    blog_content = f"AI News Summaries  {formatted_date}(By Rohit Mane Ai Agent)\n\n"
    
    for url in urls:
        print(f"Processing URL: {url}")
        title, content = scrape_article(url)
        if title and content:
            summary = summarize_article(title, content)
            if summary:
                blog_content += f" {title}\n\n"
                blog_content += f"{summary}\n\n"
                blog_content += f"**[Read the full article here]({url})**\n\n"
            else:
                blog_content += f"### {url}\n\nFailed to summarize the content.\n\n"
        else:
            blog_content += f"### {url}\n\nFailed to scrape the content.\n\n"
    
    print("Generated Blog Content:\n", blog_content)

    # Send the blog content via WhatsApp
    now = datetime.now()
    send_time = now + timedelta(seconds=60)  # Schedule message 1 minute from now
    hour = send_time.hour
    minute = send_time.minute

    try:
        pywhatkit.sendwhatmsg(phone_number, blog_content, hour, minute)
        print(f"Message scheduled to send at {hour}:{minute}")
    except Exception as e:
        print(f"An error occurred while sending the message: {e}")

# Example usage
urls = [
    "https://analyticsindiamag.com/ai-origins-evolution/what-to-expect-from-indian-it-in-2025/",
    "https://www.moneycontrol.com/news/trends/japan-s-latest-offering-is-an-ai-powered-human-washing-machine-that-cleans-you-in-15-minutes-12885887.html",
    "https://www.business-standard.com/india-news/indian-workers-lead-global-south-in-adapting-to-ai-tech-revolution-study-124120900821_1.html"
]
phone_number = "+917887655650"  # Replace with the recipient's phone number in international format
analyze_and_send(urls, phone_number)




